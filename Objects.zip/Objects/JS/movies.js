//Movie object and properties associated with the object
var movie = {
    name: "Sweet Home Alabama",
    genre: "Comedy, Romance",
    year: 2002,
    actor: "Josh Lucas",
    actress: "Reese Witherspoon"
};

//Function
function Athletes(first,last,age,height,points,championships){
    this.firstName = first;
    this.lastname = last;
    this.age = age;
    this.height = height;
    this.totalPoints = points;
    this.champs = championships;
}


//Write code to the screen
document.write("<b><font size = 8>");
document.write("The movie name is " + movie.name);
document.write("</b></font size>");
document.write("<br>");
document.write("<br>");

//Add image

//Creates new line for Genre
document.write("<font size = 5>");
document.write("The Genre is " + movie.genre);
document.write("</font size>");
document.write("<br>");

//Creates new line for Actor
document.write("<font size = 5>");
document.write("The Lead Actors are " + movie.actor + " and " + movie.actress);
document.write("</font size>");
document.write("<br>");

//Create the object
var sportsdraft = new Athletes("Lebron","James",35,80,37000,4);
//Write it to the screen
document.write("<font size = 5>");
document.write(sportsdraft.firstName + " " + sportsdraft.lastname);
document.write("</font size>");